#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "Ribrary.h"

int main()
{
    massa *li;
    li = cria_lista_massa();
    preenche_massa(li);
    return 0;
}
