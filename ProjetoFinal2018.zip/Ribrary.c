#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "Ribrary.h"

void preenche_massa(massa *li){
    FILE *f;
    massa l;
    int cont=0, cont2=0,s=0,i=0;
    char cod[6], nome[50], idade[3], emp[50], dept[50], sal[15];
    char c[150];
    f=fopen("massaDados.csv","r");
    while(fgets(c,150,f)){

    strtok(c,"/");
    strcpy(cod, c);

    strcpy(nome,strtok(NULL,"/"));
    strcpy(idade,strtok(NULL,"/"));
    strcpy(emp,strtok(NULL,"/"));
    strcpy(dept,strtok(NULL,"/"));
    strcpy(sal,strtok(NULL,"\n"));


    strreplace(sal, ',','.');
    l.cod=atoi(cod);
    l.idade=atoi(idade);
    l.sal = atof(sal);

    printf("Cod: %d ,Nome: %s, Idade: %d, Empresa: %s, Dep: %s, Sal: %.2f \n", l.cod ,nome, l.idade, emp, dept, l.sal);



    strcpy(l.nome,nome);
    strcpy(l.empresa,emp);
    strcpy(l.departamento, dept);


    }

}

massa *cria_lista_massa(){

    massa *li;
    li = (massa*) malloc(sizeof(massa));

    if(li != NULL){

        li->qtd = 0;

    }

    return li;

}

void strreplace(char *s, char chr, char repl_chr){
     int i=0;
     while(s[i]!='\0')
     {
           if(s[i]==chr)
           {
               s[i]=repl_chr;
           }
           i++;
     }
    return;
}
